http_path = "/"

css_dir = "/"

sass_dir = "/"

images_dir = "/images/"

javascripts_dir = "/js"